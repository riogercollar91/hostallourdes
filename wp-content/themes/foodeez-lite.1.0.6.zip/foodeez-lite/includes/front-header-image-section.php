<div class="Skt-header-image">
	<!-- header image -->
		<div class="foodeez-image-post"><img alt="foodeez-default-slider-image" class="ad-slider-image" width="1585"  src="<?php if( get_header_image() ) { header_image(); } else { echo get_template_directory_uri().'/images/Foodies-slider-image.jpg'; } ?>" ></div>
	<!-- end  header image  -->
</div>