<?php
/********************************************
 FRAME WORK CODE STARTS HERE
*********************************************/
require_once('sketch-functions.php');    // Pagination, excerpt control etc.
require_once('sketch-enqueue.php');      // Enqueue Css Scripts
require_once('sketch-breadcrumb.php');   // Breadcrumb function